# Garba-Guracha-Pollen-Sequence

These are the data and code used to create pollen diagrams and perform numerical analyses for the manuscript "The new Garba Guracha palynological sequence: revision and data expansion." by Graciela Gil-Romera et al. submitted to "Palaeocology of Africa". 
dictionary.csv is the file containing information on how taxa are attributed to different functional and bioclimatic types and pollen.csv contains all raw pollen data. 
Charcoal data presented in Fig3 can be downloaded from here: https://github.com/ggilromera/BaleFire
The age-depth model has been built using the dates and code published here: https://link.springer.com/article/10.1007/s10933-020-00138-w#Sec36 And the raw and calibrated dated samples can be found in the supmat_bittner_etal_2020.docx file. 
